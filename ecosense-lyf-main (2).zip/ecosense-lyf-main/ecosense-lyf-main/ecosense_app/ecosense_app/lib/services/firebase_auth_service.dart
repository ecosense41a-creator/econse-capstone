import 'package:firebase_auth/firebase_auth.dart';

import '../config.dart';
import 'auth_service.dart';

/// Real login using Firebase Authentication (email + password).
/// The admin types a username; we turn it into "<username>@<domain>".
/// Firebase Auth saves the session on the device by itself, so the user
/// stays signed in after the app is closed and reopened.
class FirebaseAuthService implements AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  String _toEmail(String username) =>
      '${username.trim().toLowerCase()}@$kUsernameEmailDomain';

  String _toUsername(String? email) => (email ?? 'admin').split('@').first;

  @override
  Stream<String?> authStateChanges() => _auth
      .authStateChanges()
      .map((user) => user == null ? null : _toUsername(user.email));

  @override
  Future<void> signIn(String username, String password) async {
    try {
      await _auth.signInWithEmailAndPassword(
        email: _toEmail(username),
        password: password,
      );
    } on FirebaseAuthException catch (e) {
      throw AuthFailure(_friendlyMessage(e.code));
    }
  }

  @override
  Future<void> signOut() => _auth.signOut();

  String _friendlyMessage(String code) {
    switch (code) {
      case 'invalid-credential':
      case 'user-not-found':
      case 'wrong-password':
      case 'invalid-email':
        return 'Incorrect username or password.';
      case 'user-disabled':
        return 'This account has been disabled.';
      case 'too-many-requests':
        return 'Too many attempts. Wait a moment and try again.';
      case 'network-request-failed':
        return 'No internet connection. Check your network and try again.';
      default:
        return 'Could not sign in ($code).';
    }
  }
}
