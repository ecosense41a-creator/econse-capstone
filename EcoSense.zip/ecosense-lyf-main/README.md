# EcoSense Flutter app

EcoSense uses Firebase Authentication for sign-in and Firebase Realtime Database for room status, sensor readings, devices, settings, and activity. The app requires an internet connection and a Firebase email/password account.

## Run the app

1. Open a terminal in `ecosense_app_run`.
2. Run `flutter pub get`, then `flutter analyze`.
3. Start an Android emulator or connect a device, and run `flutter run`.
4. Sign in using an email and password configured in Firebase Authentication.

The included Firebase configuration identifies the project's Android app. Ensure Email/Password sign-in is enabled and Realtime Database rules allow the signed-in user and hub the access they need. Data displayed depends on the data available in the database and the connected hub.

## Project structure

- `ecosense_app_run/lib/screens/`: app screens.
- `ecosense_app_run/lib/services/`: authentication and data access.
- `ecosense_app_run/lib/models/`: room, sensor, device, and energy data models.
- `ecosense_app_run/lib/config.dart`: app settings and limits.
- `backend/`: database schema, rules, and optional energy aggregation function.

If deploying the optional backend energy aggregation function, review `kEnergySyncInApp` in `lib/config.dart` to avoid counting energy twice.
