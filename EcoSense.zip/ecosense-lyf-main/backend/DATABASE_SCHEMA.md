# EcoSense database schema v2 (Firebase Realtime Database)

Design rule: **nothing the hub already writes moves.** The original flat paths
keep working and belong to the primary room (`living`). New rooms mirror the
same shape under `/rooms/<roomId>/`. Everything new is additive.

```
/room_index/<roomId>             name, created_at, user_added, pause_until      (app)
/status                          hub fused result            ┐
/sensors/mmwave | /sensors/door  raw readings                │ primary room
/logs/<pushId>                   event history               │ (existing paths,
/appliances/<deviceId>           one node per smart plug     ┘  hub writes these)
/rooms/<roomId>/{status,sensors,logs,appliances}                same shape, other rooms
/energy/<roomId>/hourly/<yyyyMMddHH>   wh, saved_wh         (Cloud Function)
/energy/<roomId>/daily/<yyyyMMdd>      wh, saved_wh         (Cloud Function)
/config                          sustained_threshold_seconds (existing)
                                 automation_mode             "auto" | "manual"
                                 electricity_rate_php        5..25
/users/<uid>/prefs/theme         "light" | "dark" | "system"
/users/<uid>/notifications_last_read    unix seconds
```

## New fields on an appliance node (`.../appliances/<deviceId>`)

Existing fields (`name, plug_ip, state, trigger_type, last_changed, power_w,
energy_wh, saved_wh_estimate, meter_updated, requested_state, requested_at`)
are unchanged. New:

| Field | Written by | Meaning |
|---|---|---|
| `auto_cutoff_allowed` | app | `true` = EcoSense may switch this off after a confirmed vacancy. **Missing = true for `plug1` only** (it is already cut automatically today); new appliances are created with `false`. |
| `rated_watts` | app | Nameplate watts entered by the admin. Used when the plug has no meter (`power_w` = 0). |
| `created_at` | app | Unix seconds. |

## Log entries (optional new fields)

Old fields stay (`type, message, confidence, timestamp`). The app also writes
entries for its own actions with `type: "manual"` plus `title`, `detail`,
`severity` (`info|warn|error`), `source: "app"`. The hub may use the same fields
(and `type: "alert"` / `"error"`) and they will appear under **Alerts**.

## Hub contract (what the hub must do for the new features)

1. **Switching** (already works): when `requested_state != state` and
   `requested_at > last_changed`, apply it to the plug, then set `state`,
   `last_changed`, `trigger_type: "manual_override"`. If not applied within
   15 s the app shows "unconfirmed" with a Retry button.
2. **Automation mode**: read `/config/automation_mode`. If `"manual"`, never
   switch anything off automatically.
3. **Opt-in cut-off**: after a confirmed vacancy, switch off only appliances
   with `auto_cutoff_allowed == true` and set `trigger_type: "auto"`
   (the app's "switched off after vacancy" banner and Restore button use it).
4. **Pause**: if `/room_index/<roomId>/pause_until` is in the future (Unix
   seconds), skip the automatic cut-off for that room and log it.
5. **Grace period**: `/config/sustained_threshold_seconds` (app allows
   10..3600 s; change `kGraceMinSeconds` in `config.dart` if the hub supports 0).
6. **Other rooms**: a hub paired to a room writes the same fields under
   `/rooms/<roomId>/...` (use the id shown in `/room_index`).
7. Keep `status/hub_last_seen` as a server timestamp (online detection).

## Energy and savings

**Two ways to fill `/energy` - use ONE, never both (they would double count):**

- *In-app (default, no Cloud Function, no hub change):* `kEnergySyncInApp = true`
  in `config.dart`. Any signed-in phone with the app open adds new energy from
  each appliance's counters to the buckets; `/energy_cursor/<room>/<device>`
  makes sure each change is counted once. Your existing totals appear at the
  time of the plug's last `meter_updated`. Usage while no phone has the app open
  is counted when it is next opened (placed at the plug's last meter time).
- *Cloud Function (always-on):* deploy `functions/`, then set
  `kEnergySyncInApp = false`.

`functions/index.js` watches every appliance node and adds the change in
`energy_wh` / `saved_wh_estimate` to hourly and daily buckets (UTC+8). The
Insights screen reads those buckets; cost = saved kWh × `electricity_rate_php`.
Without the function deployed, Insights shows "No readings yet".

## Security rules

`database.rules.json` - signed-in users can read everything, write only their
own settings, the config values (range-checked), requests on appliances
(`requested_state/at`, `auto_cutoff_allowed`), new rooms/appliances and `manual`
log entries. Hub-owned paths need `auth.token.hub === true`. If your hub uses
the Admin SDK or a service account, rules do not apply to it and nothing else is
needed. **Review against your current rules before deploying** so the hub is
not locked out:  `firebase deploy --only database,functions` from `backend/`.
