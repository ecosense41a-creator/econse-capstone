/**
 * EcoSense energy aggregation.
 *
 * Whenever a smart plug's counters change (energy_wh, saved_wh_estimate), add
 * the DIFFERENCE to hourly + daily buckets under /energy/<roomId>/, which is
 * what the Insights screen reads. No hub change is needed: the hub already
 * writes these counters on /appliances/<id>.
 *
 * Buckets are keyed in UTC+8 (Philippines). Keep this equal to
 * kEnergyUtcOffsetHours in the app's config.dart.
 *
 * Deploy (needs the Blaze plan):  firebase deploy --only functions
 */
const { onValueWritten } = require('firebase-functions/v2/database');
const { initializeApp } = require('firebase-admin/app');
const { getDatabase, ServerValue } = require('firebase-admin/database');

initializeApp();

const REGION = 'asia-southeast1'; // must match the database region
const INSTANCE = 'ecosense-capstone-default-rtdb';
const OFFSET_HOURS = 8;
const PRIMARY_ROOM = 'living'; // the room on the original flat paths
const MAX_DELTA_WH = 100000; // ignore absurd jumps (counter resets, bad data)

const pad = (n, w = 2) => String(n).padStart(w, '0');

function bucketKeys(unixSeconds) {
  const d = new Date((unixSeconds + OFFSET_HOURS * 3600) * 1000);
  const day = `${pad(d.getUTCFullYear(), 4)}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}`;
  return { day, hour: `${day}${pad(d.getUTCHours())}` };
}

async function addDelta(roomId, before, after) {
  if (!before || !after) return; // created or deleted: nothing to diff
  const dWh = (Number(after.energy_wh) || 0) - (Number(before.energy_wh) || 0);
  const dSaved =
    (Number(after.saved_wh_estimate) || 0) - (Number(before.saved_wh_estimate) || 0);
  const wh = dWh > 0 && dWh < MAX_DELTA_WH ? dWh : 0;
  const saved = dSaved > 0 && dSaved < MAX_DELTA_WH ? dSaved : 0;
  if (!wh && !saved) return;

  const ts = Number(after.meter_updated) || Math.floor(Date.now() / 1000);
  const { day, hour } = bucketKeys(ts);
  const updates = {};
  if (wh) {
    updates[`energy/${roomId}/hourly/${hour}/wh`] = ServerValue.increment(wh);
    updates[`energy/${roomId}/daily/${day}/wh`] = ServerValue.increment(wh);
  }
  if (saved) {
    updates[`energy/${roomId}/hourly/${hour}/saved_wh`] = ServerValue.increment(saved);
    updates[`energy/${roomId}/daily/${day}/saved_wh`] = ServerValue.increment(saved);
  }
  await getDatabase().ref().update(updates);
}

// Primary room: /appliances/<deviceId>
exports.energyPrimaryRoom = onValueWritten(
  { ref: '/appliances/{deviceId}', region: REGION, instance: INSTANCE },
  (event) => addDelta(PRIMARY_ROOM, event.data.before.val(), event.data.after.val()),
);

// Other rooms: /rooms/<roomId>/appliances/<deviceId>
exports.energyOtherRooms = onValueWritten(
  { ref: '/rooms/{roomId}/appliances/{deviceId}', region: REGION, instance: INSTANCE },
  (event) =>
    addDelta(event.params.roomId, event.data.before.val(), event.data.after.val()),
);
