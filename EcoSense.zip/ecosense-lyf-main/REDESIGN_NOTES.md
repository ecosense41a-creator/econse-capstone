# EcoSense UI/UX v3.2 redesign

Applied from `EcoSense_Mobile_Prototype_v2-Tinted.html` to `ecosense_app_run/`.

- Theme: `lib/theme/` (tokens for light + dark, Outfit via `google_fonts`,
  Light/Dark/System in Settings, synced to `/users/<uid>/prefs/theme`).
- Navigation: Home, Rooms, Insights, Activity, Settings (floating glass bar).
  Old Status + Sensors tabs -> Home (dial, sensors, "Hub & sensor details",
  appliance controls). Old History tab -> Activity. Old admin dialog -> Settings.
- New features with backend: multi-room, appliance list/add, per-appliance
  auto cut-off permission, automation mode, 15-minute "keep power on", restore,
  electricity rate, energy insights, notifications. See `backend/`.
- Sign-in and room data use Firebase Authentication and Realtime Database.

Not verified here: there was no Flutter SDK in the build environment, so run
`flutter pub get && flutter analyze` first and send me anything it reports.
`google_fonts` downloads Outfit on first launch (needs internet); to ship it
offline, put the Outfit .ttf files in `assets/fonts/` and declare them in pubspec.
